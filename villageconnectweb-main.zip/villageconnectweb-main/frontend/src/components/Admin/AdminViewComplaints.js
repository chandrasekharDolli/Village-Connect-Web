import React from "react";
import AdminHeader from "./AdminHeader";

const AdminViewComplaints = () => {
  return (
    <div>
      <AdminHeader />
      <h1>view comp</h1>;
    </div>
  );
};

export default AdminViewComplaints;