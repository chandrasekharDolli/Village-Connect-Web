import React from "react";

const AdminUsers = () => {
  return <h1>AdminUsers</h1>;
};

export default AdminUsers;
