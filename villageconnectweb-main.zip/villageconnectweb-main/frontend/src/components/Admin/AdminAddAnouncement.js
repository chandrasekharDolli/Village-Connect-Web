import React from "react";
import AdminHeader from "./AdminHeader";
const AdminAddAnnouncement = () => {
  return (
    <div>
      <AdminHeader />
      <h1>admin add Announcements</h1>
    </div>
  );
};

export default AdminAddAnnouncement;