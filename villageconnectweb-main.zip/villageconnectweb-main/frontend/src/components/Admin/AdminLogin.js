import React from "react";

const AdminLogin = () => {
  return <h1>AdminLogin</h1>;
};

export default AdminLogin;
