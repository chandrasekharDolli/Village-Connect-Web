import React from "react";
import AdminHeader from "./AdminHeader";

const AdminAddActivity = () => {
  return (
    <div>
      <AdminHeader />
      <h1>AdminAddActivities</h1>;
    </div>
  );
};

export default AdminAddActivity;