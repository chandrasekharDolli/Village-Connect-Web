import UserHeader from "./userHeader";

const UserServices = () => {
  return (
    <div>
      <UserHeader />
      <h1>Services</h1>
    </div>
  );
};
export default UserServices;
