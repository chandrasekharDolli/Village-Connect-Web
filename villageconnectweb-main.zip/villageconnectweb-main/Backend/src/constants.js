export const DB_NAME = "Village Connect";
